import React from 'react';
import {Composition} from 'remotion';
import {Film, TOTAL} from './Film';
import {FPS, W, H} from './theme';

export const RemotionRoot: React.FC = () => (
  <Composition
    id="Film"
    component={Film}
    durationInFrames={TOTAL}
    fps={FPS}
    width={W}
    height={H}
  />
);
